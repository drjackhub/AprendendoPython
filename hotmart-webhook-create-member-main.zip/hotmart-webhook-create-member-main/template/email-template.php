<h2>
    TEXT_1  NOME_CLIENTE,
    TEXT_2  NOME_AUTOR </h2>
    TEXT_3 

<strong>
    TEXT_4 </strong>
<ul>
    <li>
        TEXT_5 <a href="URL_SITE">URL_SITE<a/>
    </li>
    <li>
        TEXT_6 USU_LOGIN</li>
    <li>
        TEXT_7 <strong>USU_PASSWORD</strong></li>
</ul>