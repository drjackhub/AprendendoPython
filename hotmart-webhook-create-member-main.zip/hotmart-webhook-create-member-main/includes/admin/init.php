<?php 
function hmu_admin_init() {
    include( 'enqueue.php' );
    include( 'settings-api.php' );
    


    

    hmu_settings_api();
}