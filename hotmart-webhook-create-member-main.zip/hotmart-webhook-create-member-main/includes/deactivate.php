<?php 
function hmu_deactivate_plugin () {

}