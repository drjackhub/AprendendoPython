![Logotipo do eVendas](/Imagens/Logos/Logotipo.png)
# eVendas

Projeto de sistema voltado para a área de vendas e automação comercial com uso de servidor Horse.
