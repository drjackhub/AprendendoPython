<p align="center">
  <img alt="" src=".github/thumbnail.jpg" width="100%">
</p>

## 🚀 Tecnologias

Esse projeto foi desenvolvido com as seguintes tecnologias:

- HTML
- CSS
- JavaScript
- [AOS](https://lnkd.in/d43vEajg)
- [SVGArtista](https://svgartista.net/)
- [This Person Does Not Exist](https://this-person-does-not-exist.com/pt)

## 🚧 Projeto:

Essa página é um ranking da competição onde os top 3 infoprodutores de maior faturamento da kiwify.

## 🎨 Inspiração:

Behance: https://www.behance.net/gallery/155609865/Leaderboard/modules/877995027

---

Feito com ♥ by birobirobiro
