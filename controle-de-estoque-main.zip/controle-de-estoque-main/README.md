# controle-de-estoque
Sistema de automação de processos, emissor de sinais, overview de estoque, pedidos e vendas

# Instruções
- Instalar PyCharm;
- Instalar Python-3.8.5;
- Criar VirtualEnv (Fora do projeto);
- Instalar Requirements;
- Instalar PostgreSQL (SGBD);
- Criar banco de dados e garantir permissões ao usuario do banco de dados;
- Copiar .env.desenvolvimento, colar na raíz do projeto alterando o nome para ".env"
- Rodar comandos: Migrate e Makemigrations;
- Criar superuser; e
- Começar a desenvolver

# Jira
https://rivoteam.atlassian.net/secure/RapidBoard.jspa?projectKey=AR&rapidView=2
