from django.apps import AppConfig


class ControleEstoqueConfig(AppConfig):
    name = 'controle_estoque'
