from django.apps import AppConfig


class ControleVendasConfig(AppConfig):
    name = 'controle_vendas'
