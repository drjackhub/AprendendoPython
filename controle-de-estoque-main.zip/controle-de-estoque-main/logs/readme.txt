Resumo das funcionalidades de cada arquivo de log.
