from django.apps import AppConfig


class ControleUsuariosConfig(AppConfig):
    name = 'controle_usuarios'
