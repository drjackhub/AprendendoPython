export declare type User = {
    email: string
    name?: string
    password: string
}