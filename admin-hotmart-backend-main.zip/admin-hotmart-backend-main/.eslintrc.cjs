module.exports = {
    // Note: you must disable the base rule as it can report incorrect errors
    "quotes": "off",
    "@typescript-eslint/quotes": "warn"
};