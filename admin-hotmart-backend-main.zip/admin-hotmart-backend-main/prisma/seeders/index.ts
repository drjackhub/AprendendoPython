/**
 * Put all seeders filename here. It will be executed based on the order
 */
export default ['AdminSeeder']
