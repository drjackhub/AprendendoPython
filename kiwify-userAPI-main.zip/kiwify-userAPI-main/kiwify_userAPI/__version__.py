__version__ = '1.0.0.0'
__lib_name__ = 'kiwify_userAPI'
__repo_name__ = 'kiwify-userAPI'
__autor__ = 'PauloCesar-dev404'
__repo__ = f'https://github.com/PauloCesar-dev404/{__repo_name__}'
__description__ = """Obtenha detalhes de cursos que o usuário esteja inscrito da plataforma kiwify,usando o EndPoint 
de usuário o mesmo que o navegador utiliza para acessar e redenrizar os cursos."""
