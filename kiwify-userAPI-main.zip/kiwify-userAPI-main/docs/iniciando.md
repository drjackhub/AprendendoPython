<div align="center">
    <img src="../assets/kiwify_userAPI-logo.png" alt="kiwify_userAPI-logo" width="200"/> 

![Versão](https://img.shields.io/badge/version-1.0.0.0-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://paulocesar-dev404.github.io/me-apoiando-online/)
[![Sponsor](https://img.shields.io/badge/Documentation-green)](https://github.com/PauloCesar-dev404/kiwify-userAPI/blob/main/docs/iniciando.md)


<i>A biblioteca `kiwify_userAPI` facilita a análise de cursos na Kiwify.
</i>
  
  ---
</div>


- [instalação](instalação.md) 
- [Realizando Login](Realizando%20Login.md)
- [Obtendo Os Cursos Que Estou Inscrito](Obtendo%20Os%20Cursos%20Que%20Estou%20Inscrito.md)
- [Obter Detalhes De Um Curso.md](Obter%20Detalhes%20De%20Um%20Curso.md)
- [Obter Detalhes de Uma Aula.md](Obter%20Detalhes%20de%20Uma%20Aula.md)

