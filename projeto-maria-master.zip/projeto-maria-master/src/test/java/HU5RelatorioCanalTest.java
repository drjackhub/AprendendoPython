import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HU5RelatorioCanalTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
