package br.senai.sc.edu.projetomaria.cli;

public enum RelatorioEnum {
	
	PRODUTO, FAMILIA, CANAL, HISTORICO, ESTIMATIVA, PHASE;

}
