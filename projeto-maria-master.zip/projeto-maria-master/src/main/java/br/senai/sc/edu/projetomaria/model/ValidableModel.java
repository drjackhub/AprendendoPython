package br.senai.sc.edu.projetomaria.model;

public interface ValidableModel {

	public boolean isValid();
	
}
