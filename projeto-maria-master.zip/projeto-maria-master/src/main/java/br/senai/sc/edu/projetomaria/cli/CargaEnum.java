package br.senai.sc.edu.projetomaria.cli;

public enum CargaEnum {
	
	PRODUTO, FAMILIA, CANAL, HISTORICO, PHASE;

}
