package br.senai.sc.edu.projetomaria.model;

public class Phase {
	private int skuOld;
	private int skuNew;
	public int getSkuOld() {
		return skuOld;
	}
	public void setSkuOld(int skuOld) {
		this.skuOld = skuOld;
	}
	public int getSkuNew() {
		return skuNew;
	}
	public void setSkuNew(int skuNew) {
		this.skuNew = skuNew;
	}
	
}
